#!/bin/sh

python test-ps3-partB.py
