# heap_sort() returns a copy of list A sorted in descending order.
# For example, heapsort([4,8,3,6]) should return [8,6,4,3].
# heap_sort() should NOT modify the list A.
def heap_sort(A):
    # YOUR CODE HERE
    raise NotImplementedError("heap_sort() has not been implemented yet")

# This function takes a list which contains the daily penalties for
# each problem set, and returns the smallest total penalty Ben can
# achieve. You should use your heap_sort() implementation.
def best_score(penalties):
    # YOUR CODE HERE
    raise NotImplementedError("best_score() has not been implemented yet")
