#!/bin/sh

python test-ps1-part1.py