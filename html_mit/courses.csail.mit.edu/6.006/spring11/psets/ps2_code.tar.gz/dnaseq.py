#!/usr/bin/env python2.7

import unittest
from dnaseqlib import *

### Utility classes ###

# Produces hash values for a rolling sequence.
class RollingHash:
    # Initializes a new rolling hash of the iterable sequence s.
    # (Remember that, in Python, this includes strings!)
    def __init__(self, s):
        raise Exception("Not implemented!")

    # Returns the current hash value.
    def hash(self):
        raise Exception("Not implemented!")

    # Updates the hash by removing previtm and adding nextitm.
    # Returns the updated hash value.
    def slide(self, previtm, nextitm):
        raise Exception("Not implemented!")

# Maps integer keys to a set of arbitrary values.
class Multidict:
    # Initializes a new multi-value dictionary, and adds any key-value
    # 2-tuples in the iterable sequence pairs to the data structure.
    def __init__(self, pairs=[]):
        raise Exception("Not implemented!")
    # Associates the value v with the key k.
    def put(self, k, v):
        raise Exception("Not implemented!")
    # Gets any values that have been associated with the key k; or, if
    # none have been, returns an empty sequence.
    def get(self, k):
        raise Exception("Not implemented!")

# Given a sequence of nucleotides, return all k-length subsequences
# and their hashes.  (What else do you need to know about each
# subsequence?)
def subsequenceHashes(seq, k):
    raise Exception("Not implemented!")

# Similar to subsequenceHashes(), but returns one k-length subsequence
# every m nucleotides.  (This will be useful when you try to use two
# whole data files.)
def intervalSubsequenceHashes(seq, k, m):
    raise Exception("Not implemented!")

# Searches for commonalities between sequences a and b by comparing
# subsequences of length k.  The sequences a and b should be iterators
# that return nucleotides.  The table is built by computing one hash
# every m nucleotides (for m >= k).
def getExactSubmatches(a, b, k, m):
    raise Exception("Not implemented!")

# Uncomment this when you're ready to generate comparison images.  The
# arguments are, in order: 1) Your getExactSubmatches function, 2) the
# filename to which the image should be written, 3) a tuple giving the
# width and height of the image, 4) the filename of sequence A, 5) the
# filename of sequence B, 6) k, the subsequence size, and 7) m, the
# sampling interval for sequence A.
#compareSequences(getExactSubmatches, 'maternal-paternal.png', (500,500), 'fmaternal.fa', 'fpaternal.fa', 20, 10000)

### Testing ###

class TestRollingHash(unittest.TestCase):
    def test_rolling(self):
        rh1 = RollingHash('abcde')
        rh2 = RollingHash('bcdef')
        rh3 = RollingHash('cdefZ')
        rh1.slide('a','f')
        self.assertTrue(rh1.hash() == rh2.hash())
        rh1.slide('b','Z')
        self.assertTrue(rh1.hash() == rh3.hash())

class TestMultidict(unittest.TestCase):
    def test_multi(self):
        foo = Multidict()
        foo.put(1, 'a')
        foo.put(2, 'b')
        foo.put(1, 'c')
        self.assertTrue(foo.get(1) == ['a','c'])
        self.assertTrue(foo.get(2) == ['b'])
        self.assertTrue(foo.get(3) == [])

# This test case may be useful before you add the argument m
#class TestExactSubmatches(unittest.TestCase):
#    def test_one(self):
#        foo = 'yabcabcabcz'
#        bar = 'xxabcxxxx'
#        matches = list(getExactSubmatches(iter(foo), iter(bar), 3, 1))
#        correct = [(1,2), (4,2), (7,2)]
#        self.assertTrue(len(matches) == len(correct))
#        for x in correct:
#            self.assertTrue(x in matches)

#if __name__ == '__main__':
#    unittest.main()
