#!/bin/sh

python test-ps1-part2.py